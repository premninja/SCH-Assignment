const express = require('express');
const fs = require('fs');
const app = express();
const PORT = 3000;

app.use(express.json());
if(!fs.existsSync("./rules.json")){
 console.error("Failed to load rules.json");
  process.exit(1);
}
let rules = require("./rules.json")



function evaluateCondition(condition, prData) {
  try {
  
    const func = new Function(...Object.keys(prData), `return ${condition};`);
    return func(...Object.values(prData));
  } catch (err) {
    console.error("Condition Evaluation Error:", err);
    return false;
  }
}

// POST /processPR
app.post('/processPR', (req, res) => {
  let pr = { ...req.body }; // clone input safely

  for (let rule of rules.approvalRules) {
    if (evaluateCondition(rule.condition, pr)) {
      if (rule.action === 'autoApprove' && rule.setStatus) {
        pr.status = rule.setStatus;
      }
      if (rule.action === 'setUrgency' && rule.urgency) {
        pr.urgency = rule.urgency;
      }
    }
  }

  res.json(pr);
});

// Start server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});