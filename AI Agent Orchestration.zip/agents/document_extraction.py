def run(input_data):
    # Simulate extracting fields from a document
    extracted = {
        "name": input_data.get("raw", {}).get("name", "").strip(),
        "email": input_data.get("raw", {}).get("email", "").strip()
    }
    return extracted