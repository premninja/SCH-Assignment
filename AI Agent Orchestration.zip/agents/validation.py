def run(input_data):
    if not input_data.get("name") or not input_data.get("email"):
        raise ValueError("Validation Failed: 'name' and 'email' are required")
    if "@" not in input_data["email"]:
        raise ValueError("Validation Failed: Invalid email format")
    return input_data
