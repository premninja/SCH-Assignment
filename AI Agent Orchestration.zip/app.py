from flask import Flask, request, jsonify
import json
import importlib

app = Flask(__name__)

# Load orchestration flow
with open("orchestration_flow.json") as f:
    orchestration = json.load(f)


@app.route("/executeAgentFlow", methods=["POST"])
def execute_agent_flow():
    try:
        data = request.get_json()
        current_data = data

        for agent_name in orchestration["flow"]:
            module_name = f"agents.{agent_name.lower().replace('agent', '')}"
            agent_module = importlib.import_module(module_name)
            current_data = agent_module.run(current_data)

        return jsonify({"result": current_data}), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 400


if __name__ == "__main__":
    app.run(debug=True, port=5000)
