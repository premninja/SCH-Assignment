const express = require('express');
const router = express.Router();
const PurchaseOrder = require('../models/PurchaseOrder');
const Invoice = require('../models/Invoice');

router.get('/spend-analysis', async (req, res) => {
  try {
    const poAggregation = await PurchaseOrder.aggregate([
      { $group: { _id: "$vendor", totalPOAmount: { $sum: "$amount" } } }
    ]);

    const invoiceAggregation = await Invoice.aggregate([
      { $group: { _id: "$vendor", totalPaidAmount: { $sum: "$paid_amount" } } }
    ]);

    // Merge both aggregations by vendor
    const resultMap = {};

    poAggregation.forEach(({_id,totalPOAmount,totalPaidAmount=0}) => {
      resultMap[_id] = { vendor:_id, totalPOAmount, totalPaidAmount };
    });

    invoiceAggregation.forEach(({_id,totalPOAmount=0,totalPaidAmount}) => {
      if (!resultMap[_id]) {
        resultMap[_id] = { vendor:_id, totalPOAmount, totalPaidAmount };
      } else {
        resultMap[_id].totalPaidAmount =totalPaidAmount;
      }
    });

    const report = Object.values(resultMap);

    res.json(report);
  } catch (err) {
    res.status(500).json({ error: 'Failed to generate report', details: err.message });
  }
});

module.exports = router;
