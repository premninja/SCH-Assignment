const mongoose = require('mongoose');

const InvoiceSchema = new mongoose.Schema({
  vendor: String,
  paid_amount: Number,
  date: Date
});

module.exports = mongoose.model('Invoice', InvoiceSchema);
