const mongoose = require('mongoose');

const PurchaseOrderSchema = new mongoose.Schema({
  vendor: String,
  amount: Number,
  date: Date
});

module.exports = mongoose.model('PurchaseOrder', PurchaseOrderSchema);
