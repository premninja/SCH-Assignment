const express = require('express');
const mongoose = require('mongoose');
const reportsRoute = require('./router/route');

const app = express();
const PORT = 3000;
const MONGO_URI = 'mongodb://localhost:27017/procurement';

mongoose.connect(MONGO_URI)
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.error('MongoDB error', err));

app.use(express.json());
app.use('/', reportsRoute);

app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));
