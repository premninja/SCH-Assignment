const mongoose = require('mongoose');
const PurchaseOrder = require('./models/PurchaseOrder');
const Invoice = require('./models/Invoice');

const MONGO_URI = 'mongodb://localhost:27017/procurement';

(async () => {
  await mongoose.connect(MONGO_URI);
  await PurchaseOrder.deleteMany();
  await Invoice.deleteMany();

  await PurchaseOrder.insertMany([
    { vendor: 'Vendor A', amount: 1000, date: new Date() },
    { vendor: 'Vendor B', amount: 2000, date: new Date() },
    { vendor: 'Vendor A', amount: 500, date: new Date() },
  ]);

  await Invoice.insertMany([
    { vendor: 'Vendor A', paid_amount: 800, date: new Date() },
    { vendor: 'Vendor B', paid_amount: 1500, date: new Date() },
    { vendor: 'Vendor C', paid_amount: 700, date: new Date() },
  ]);

  console.log('Sample data inserted.');
  process.exit();
})()

